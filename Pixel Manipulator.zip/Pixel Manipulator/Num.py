from tkinter import Tk
from tkinter.filedialog import askopenfilename
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt

# Step 1: Open file dialog to select an image
def select_image():
    Tk().withdraw()  # Hide the main Tk window
    file_path = askopenfilename(
        title="Select an image",
        filetypes=[("Image files", "*.png;*.jpg;*.jpeg;*.bmp")]
    )
    return file_path

def encrypt_pixel_values(img_array, key):
    # Convert to int16 before math to avoid overflow
    img_array = img_array.astype(np.int16)
    encrypted = (img_array + key) % 256
    return encrypted.astype(np.uint8)

def decrypt_pixel_values(encrypted_array, key):
    encrypted_array = encrypted_array.astype(np.int16)
    decrypted = (encrypted_array - key) % 256
    return decrypted.astype(np.uint8)


def save_image(img_array, path):
    Image.fromarray(img_array).save(path)


# Step 2: Load image as array
def load_image(path):
    img = Image.open(path)
    img_array = np.array(img)
    return img, img_array

# Step 3: Display image
def show_image(img, title="Image"):
    plt.imshow(img)
    plt.title(title)
    plt.axis('off')
    plt.show()

# Main logic
if __name__ == "__main__":
    image_path = select_image()
    if image_path:
        print(f"Selected image path: {image_path}")
        img, img_array = load_image(image_path)
        show_image(img, "Original Image")
        print(f"Image shape: {img_array.shape}")  # Confirm shape

        key = 50  # Key for encryption
        encrypted_array = encrypt_pixel_values(img_array, key)
        save_image(encrypted_array, "encrypted.png")
        show_image(encrypted_array, "Encrypted Image")

        decrypted_array = decrypt_pixel_values(encrypted_array, key)
        save_image(decrypted_array, "decrypted.png")
        show_image(decrypted_array, "Decrypted Image")
    else:
        print("No image selected.")
